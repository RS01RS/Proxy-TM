package com.rs.proxy;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * فرستادن فایل به برنامه‌های دیگر (بلوتوث، Quick Share، تلگرام، …) بدون androidx:
 * فقط فایل‌های پوشهٔ cache/share و خود فایل نصب برنامه (برای «ارسال برنامه») قابل خواندن‌اند.
 */
public class RsFiles extends ContentProvider {
    static final String AUTH = "com.rs.proxy.files";

    static Uri uriFor(String name) { return Uri.parse("content://" + AUTH + "/" + Uri.encode(name)); }

    private File fileOf(Uri uri) throws FileNotFoundException {
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) throw new FileNotFoundException();
        if (name.startsWith("TM-Proxy-") && name.endsWith(".apk")) return new File(getContext().getApplicationInfo().sourceDir);   // خود برنامه
        File f = new File(new File(getContext().getCacheDir(), "share"), name);
        if (!f.exists()) throw new FileNotFoundException(name);
        return f;
    }

    @Override public boolean onCreate() { return true; }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(fileOf(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String n = String.valueOf(uri.getLastPathSegment());
        return n.endsWith(".apk") ? "application/vnd.android.package-archive" : n.endsWith(".json") ? "application/json" : n.endsWith(".ovpn") ? "application/x-openvpn-profile" : "text/plain";
    }

    @Override
    public Cursor query(Uri uri, String[] proj, String sel, String[] args, String sort) {
        MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
        try { File f = fileOf(uri); c.addRow(new Object[]{uri.getLastPathSegment(), f.length()}); } catch (Exception ignored) { }
        return c;
    }

    @Override public Uri insert(Uri uri, ContentValues v) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
