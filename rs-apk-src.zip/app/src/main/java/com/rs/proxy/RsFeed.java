package com.rs.proxy;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;

/**
 * thefeed (github.com/sartoopjj/thefeed، MIT): پیام‌های کانال‌های تلگرامِ یک سرور thefeed از راه DNS.
 * libfeed.so (برنامهٔ rsfeed) یک بار اجرا می‌شود و JSON کانال‌ها و پیام‌ها را چاپ می‌کند.
 */
final class RsFeed {
    private RsFeed() { }

    static boolean available(Context c) { return new File(c.getApplicationInfo().nativeLibraryDir, "libfeed.so").exists(); }

    /** profile: {"domain","key","sk","extra":[…],"resolvers":[…]} → {"ok":true,"channels":[{name,title,msgs:[…]}]} */
    static String fetch(Context c, String profileJson, String bankJson, int timeoutSec) {
        Process p = null;
        try {
            File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libfeed.so");
            if (!bin.exists()) return "{\"ok\":false,\"err\":\"" + (MainActivity.EN ? "thefeed isn't in this build of the app" : "thefeed در این نسخهٔ برنامه نیست") + "\"}";
            JSONObject pr = new JSONObject(profileJson);
            LinkedHashSet<String> rs = new LinkedHashSet<>();
            JSONArray a = pr.optJSONArray("resolvers");
            if (a != null) for (int i = 0; i < a.length(); i++) rs.add(a.optString(i).trim());
            try { JSONArray b = new JSONArray(bankJson); for (int i = 0; i < b.length(); i++) rs.add(b.optString(i).trim()); } catch (Exception ignored) { }
            rs.addAll(RsDns.resolvers(c, null));
            rs.remove("");
            JSONObject cfg = new JSONObject();
            cfg.put("domain", pr.optString("domain"));
            cfg.put("key", pr.optString("key"));
            cfg.put("sk", pr.optString("sk"));
            cfg.put("extra", pr.optJSONArray("extra") == null ? new JSONArray() : pr.optJSONArray("extra"));
            JSONArray ra = new JSONArray(); int n = 0; for (String r : rs) { if (n++ >= 300) break; ra.put(r); }
            cfg.put("resolvers", ra);
            cfg.put("timeoutSec", Math.max(20, timeoutSec - 5));
            File dir = new File(c.getFilesDir(), "feed"); dir.mkdirs();
            File cf = new File(dir, "rsfeed.json");
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(cfg.toString().getBytes(StandardCharsets.UTF_8)); }
            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "-c", cf.getAbsolutePath());
            pb.directory(dir);
            pb.redirectError(new File(dir, "rsfeed.log"));   // (Redirect.DISCARD در اندروید نیست)
            pb.environment().put("HOME", dir.getAbsolutePath());
            p = pb.start();
            final Process pp = p;
            final StringBuilder out = new StringBuilder();
            Thread rd = new Thread(() -> {
                try (InputStream in = pp.getInputStream()) {
                    byte[] buf = new byte[16384]; int k;
                    while ((k = in.read(buf)) > 0) { synchronized (out) { if (out.length() < 6_000_000) out.append(new String(buf, 0, k, StandardCharsets.UTF_8)); } }
                } catch (Exception ignored) { }
            });
            rd.start();
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return "{\"ok\":false,\"err\":\"timeout\"}"; }
            rd.join(3000);
            String s; synchronized (out) { s = out.toString().trim(); }
            int nl = s.lastIndexOf('\n'); if (nl >= 0) s = s.substring(nl + 1);
            return s.startsWith("{") ? s : "{\"ok\":false,\"err\":\"no output\"}";
        } catch (Throwable t) {
            if (p != null) p.destroyForcibly();
            return "{\"ok\":false,\"err\":" + JSONObject.quote(String.valueOf(t.getMessage())) + "}";
        }
    }

    /**
     * یک فایل (عکس / فایل) را از رلهٔ DNS سرور thefeed می‌گیرد و در cache/share می‌گذارد.
     * meta: {"ch","blk","crc","name"} → {"ok":true,"name","size","b64"?}
     */
    static String media(Context c, String profileJson, String bankJson, String metaJson, int timeoutSec) {
        Process p = null;
        try {
            File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libfeed.so");
            if (!bin.exists()) return "{\"ok\":false,\"err\":\"" + (MainActivity.EN ? "thefeed isn't in this build of the app" : "thefeed در این نسخهٔ برنامه نیست") + "\"}";
            JSONObject pr = new JSONObject(profileJson), m = new JSONObject(metaJson);
            LinkedHashSet<String> rs = new LinkedHashSet<>();
            JSONArray a = pr.optJSONArray("resolvers");
            if (a != null) for (int i = 0; i < a.length(); i++) rs.add(a.optString(i).trim());
            try { JSONArray b = new JSONArray(bankJson); for (int i = 0; i < b.length(); i++) rs.add(b.optString(i).trim()); } catch (Exception ignored) { }
            rs.addAll(RsDns.resolvers(c, null));
            rs.remove("");
            String name = "feed_" + m.optString("name", "file").replaceAll("[^A-Za-z0-9._-]", "_");
            if (name.length() > 80) name = name.substring(name.length() - 80);
            File dir = new File(c.getCacheDir(), "share"); dir.mkdirs();
            File outF = new File(dir, name);
            JSONObject cfg = new JSONObject();
            cfg.put("domain", pr.optString("domain"));
            cfg.put("key", pr.optString("key"));
            cfg.put("sk", pr.optString("sk"));
            cfg.put("extra", pr.optJSONArray("extra") == null ? new JSONArray() : pr.optJSONArray("extra"));
            JSONArray ra = new JSONArray(); int n = 0; for (String r : rs) { if (n++ >= 300) break; ra.put(r); }
            cfg.put("resolvers", ra);
            cfg.put("timeoutSec", Math.max(20, timeoutSec - 5));
            JSONObject mo = new JSONObject();
            mo.put("ch", m.optInt("ch")); mo.put("blk", m.optInt("blk")); mo.put("crc", m.optString("crc"));
            mo.put("out", outF.getAbsolutePath()); mo.put("max", 2L << 20);
            cfg.put("media", mo);
            File fdir = new File(c.getFilesDir(), "feed"); fdir.mkdirs();
            File cf = new File(fdir, "rsfeed_media.json");
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(cfg.toString().getBytes(StandardCharsets.UTF_8)); }
            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "-c", cf.getAbsolutePath());
            pb.directory(fdir);
            pb.redirectError(new File(fdir, "rsfeed_media.log"));
            pb.environment().put("HOME", fdir.getAbsolutePath());
            p = pb.start();
            final Process pp = p;
            final StringBuilder out = new StringBuilder();
            Thread rd = new Thread(() -> {
                try (InputStream in = pp.getInputStream()) {
                    byte[] buf = new byte[8192]; int k;
                    while ((k = in.read(buf)) > 0) { synchronized (out) { if (out.length() < 100000) out.append(new String(buf, 0, k, StandardCharsets.UTF_8)); } }
                } catch (Exception ignored) { }
            });
            rd.start();
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); return "{\"ok\":false,\"err\":\"timeout\"}"; }
            rd.join(3000);
            String s; synchronized (out) { s = out.toString().trim(); }
            int nl = s.lastIndexOf('\n'); if (nl >= 0) s = s.substring(nl + 1);
            JSONObject r = s.startsWith("{") ? new JSONObject(s) : new JSONObject().put("ok", false).put("err", "no output");
            if (r.optBoolean("ok") && outF.exists()) {
                r.put("name", name); r.put("size", outF.length());
                if (outF.length() <= 1_600_000) {
                    byte[] data = new byte[(int) outF.length()];
                    try (java.io.FileInputStream fi = new java.io.FileInputStream(outF)) { int off = 0, k; while (off < data.length && (k = fi.read(data, off, data.length - off)) > 0) off += k; }
                    r.put("b64", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
                }
            }
            return r.toString();
        } catch (Throwable t) {
            if (p != null) p.destroyForcibly();
            return "{\"ok\":false,\"err\":" + JSONObject.quote(String.valueOf(t.getMessage())) + "}";
        }
    }

    /** فایل گرفته‌شده را در Download/TM-Proxy ذخیره می‌کند (اندروید ۱۰+)؛ نسخه‌های قدیمی‌تر: false */
    static boolean saveToDownloads(Context c, String name, String mime) {
        try {
            if (name == null || name.contains("/") || name.contains("..")) return false;
            File f = new File(new File(c.getCacheDir(), "share"), name);
            if (!f.exists() || android.os.Build.VERSION.SDK_INT < 29) return false;
            android.content.ContentValues v = new android.content.ContentValues();
            String shown = name.startsWith("feed_") ? name.substring(5) : name;
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, shown);
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/TM-Proxy");
            android.net.Uri u = c.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) return false;
            try (java.io.OutputStream o = c.getContentResolver().openOutputStream(u); java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] buf = new byte[16384]; int k; while ((k = in.read(buf)) > 0) o.write(buf, 0, k);
            }
            return true;
        } catch (Exception e) { return false; }
    }
}
