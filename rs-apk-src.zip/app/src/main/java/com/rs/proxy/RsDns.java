package com.rs.proxy;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;

/**
 * کلاینت سادهٔ DNS (UDP، و TCP اگر جواب بزرگ بود) برای خواندن رکوردهای TXT.
 * کاربرد: «کانفیگ از رکورد TXT دامنه» — در قطعی‌ها معمولاً DNSهای داخلی هنوز به بیرون راه دارند.
 *
 * قالب دامنه:
 *  - هر رکورد TXT = یک یا چند کانفیگ (با فاصله / خط جدا)، یا base64 یک لیست
 *  - اگر رکورد «n=5» باشد، 1.دامنه تا 5.دامنه هم خوانده می‌شوند (برای لیست‌های بزرگ)
 */
final class RsDns {
    private RsDns() { }
    private static final Random rnd = new Random();

    /** ساخت پرسش DNS */
    static byte[] query(int id, String name, int type) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(id >> 8); o.write(id & 255);
        o.write(1); o.write(0);              // RD
        o.write(0); o.write(1);              // QDCOUNT
        for (int i = 0; i < 6; i++) o.write(0);
        for (String l : name.replaceAll("\\.$", "").split("\\.")) {
            byte[] b = l.getBytes(StandardCharsets.US_ASCII);
            o.write(b.length); o.write(b, 0, b.length);
        }
        o.write(0);
        o.write(type >> 8); o.write(type & 255);
        o.write(0); o.write(1);              // IN
        return o.toByteArray();
    }

    private static int skipName(byte[] m, int p) {
        while (p < m.length) {
            int l = m[p] & 255;
            if (l == 0) return p + 1;
            if ((l & 0xC0) == 0xC0) return p + 2;
            p += l + 1;
        }
        return p;
    }

    static final class Ans { int rcode; boolean truncated; List<String> txt = new ArrayList<>(); }

    /** خواندن جواب: فقط رکوردهای TXT (هر رکورد = به‌هم‌چسباندن رشته‌هایش) */
    static Ans parse(byte[] m, int len, int id) {
        if (len < 12 || (((m[0] & 255) << 8) | (m[1] & 255)) != id) return null;
        Ans a = new Ans();
        a.truncated = (m[2] & 2) != 0;
        a.rcode = m[3] & 15;
        int qd = ((m[4] & 255) << 8) | (m[5] & 255), an = ((m[6] & 255) << 8) | (m[7] & 255);
        int p = 12;
        for (int i = 0; i < qd; i++) p = skipName(m, p) + 4;
        for (int i = 0; i < an && p + 10 <= len; i++) {
            p = skipName(m, p);
            int type = ((m[p] & 255) << 8) | (m[p + 1] & 255);
            int rdl = ((m[p + 8] & 255) << 8) | (m[p + 9] & 255);
            p += 10;
            if (p + rdl > len) break;
            if (type == 16) {
                StringBuilder sb = new StringBuilder();
                int q = p;
                while (q < p + rdl) { int l = m[q] & 255; q++; sb.append(new String(m, q, Math.min(l, p + rdl - q), StandardCharsets.UTF_8)); q += l; }
                a.txt.add(sb.toString());
            }
            p += rdl;
        }
        return a;
    }

    /** یک پرسش TXT از یک resolver (UDP؛ اگر جواب بریده شد → TCP). null یعنی جوابی نیامد. */
    static List<String> txt(String name, String resolver, int timeoutMs) {
        String host = resolver; int port = 53;
        int c = resolver.lastIndexOf(':');
        if (c > 0 && resolver.indexOf(':') == c) { host = resolver.substring(0, c); try { port = Integer.parseInt(resolver.substring(c + 1)); } catch (Exception ignored) { } }
        int id = rnd.nextInt(65535);
        byte[] q = query(id, name, 16);
        try (DatagramSocket s = new DatagramSocket()) {
            s.setSoTimeout(timeoutMs);
            InetAddress ad = InetAddress.getByName(host);
            s.send(new DatagramPacket(q, q.length, ad, port));
            byte[] buf = new byte[4096];
            long until = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < until) {
                DatagramPacket pk = new DatagramPacket(buf, buf.length);
                s.receive(pk);
                Ans a = parse(buf, pk.getLength(), id);
                if (a == null) continue;
                if (a.truncated) return tcp(name, host, port, timeoutMs);
                return a.rcode == 0 || a.rcode == 3 ? a.txt : null;
            }
        } catch (Exception ignored) { }
        return null;
    }

    static List<String> tcp(String name, String host, int port, int timeoutMs) {
        int id = rnd.nextInt(65535);
        byte[] q = query(id, name, 16);
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            s.setSoTimeout(timeoutMs);
            OutputStream o = s.getOutputStream();
            byte[] f = new byte[q.length + 2]; f[0] = (byte) (q.length >> 8); f[1] = (byte) q.length;
            System.arraycopy(q, 0, f, 2, q.length); o.write(f); o.flush();
            DataInputStream in = new DataInputStream(s.getInputStream());
            int len = in.readUnsignedShort();
            byte[] m = new byte[len]; in.readFully(m);
            Ans a = parse(m, len, id);
            return a == null ? null : a.txt;
        } catch (Exception e) { return null; }
    }

    /** اولین resolver که جواب داد (به نوبت) */
    static List<String> txtAny(String name, List<String> resolvers, int timeoutMs) {
        for (int i = 0; i < resolvers.size(); i++) {
            List<String> t = txt(name, resolvers.get(i), timeoutMs);
            if (t != null) {
                // resolverی که جواب داد برای پرسش‌های بعدی اول صف می‌رود
                if (i > 0) { try { resolvers.add(0, resolvers.remove(i)); } catch (UnsupportedOperationException ignored) { } }
                return t;
            }
        }
        return null;
    }

    private static String maybeB64(String s) {
        String t = s.trim();
        if (t.contains("://") || t.length() < 16 || !t.matches("[A-Za-z0-9+/=_-]+")) return s;
        try {
            String d = new String(java.util.Base64.getMimeDecoder().decode(t.replace('-', '+').replace('_', '/')), StandardCharsets.UTF_8);
            return d.contains("://") ? d : s;
        } catch (Exception e) { return s; }
    }

    /** همهٔ کانفیگ‌های یک دامنه (با n=…)؛ null اگر هیچ resolverی جواب نداد */
    static String collect(String domain, List<String> resolvers, int timeoutMs) {
        domain = domain.trim().replaceAll("^[a-z]+://", "").replaceAll("/.*$", "");
        if (domain.isEmpty()) return null;
        resolvers = new ArrayList<>(resolvers);
        List<String> first = txtAny(domain, resolvers, timeoutMs);
        if (first == null) return null;
        LinkedHashSet<String> out = new LinkedHashSet<>();
        int n = 0;
        for (String t : first) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^\\s*n\\s*=\\s*(\\d{1,3})\\s*$").matcher(t);
            if (m.find()) n = Math.min(200, Integer.parseInt(m.group(1)));
            else out.add(maybeB64(t));
        }
        for (int i = 1; i <= n; i++) {
            List<String> part = txtAny(i + "." + domain, resolvers, timeoutMs);
            if (part != null) for (String t : part) out.add(maybeB64(t));
        }
        return String.join("\n", out);
    }

    /**
     * آیا این resolver «بازگشتی» کار می‌کند (یعنی تا سرورهای بیرون می‌رود)؟ زمان پاسخ (ms) یا -1.
     * یک نام تصادفی زیر یک دامنهٔ معروف پرسیده می‌شود: جواب NXDOMAIN/NOERROR یعنی واقعاً جست‌وجو کرده.
     */
    static long probe(String resolver, int timeoutMs) {
        String host = resolver; int port = 53;
        int c = resolver.lastIndexOf(':');
        if (c > 0 && resolver.indexOf(':') == c) { host = resolver.substring(0, c); try { port = Integer.parseInt(resolver.substring(c + 1)); } catch (Exception ignored) { } }
        String[] zones = {"google.com", "cloudflare.com", "microsoft.com"};
        String name = "rs" + Long.toHexString(rnd.nextLong() & 0xffffffffffL) + "." + zones[rnd.nextInt(zones.length)];
        int id = rnd.nextInt(65535);
        byte[] q = query(id, name, 1);
        try (DatagramSocket s = new DatagramSocket()) {
            s.setSoTimeout(timeoutMs);
            long t0 = System.nanoTime();
            s.send(new DatagramPacket(q, q.length, InetAddress.getByName(host), port));
            byte[] buf = new byte[1500];
            long until = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < until) {
                DatagramPacket pk = new DatagramPacket(buf, buf.length);
                s.receive(pk);
                Ans a = parse(buf, pk.getLength(), id);
                if (a == null) continue;
                if (a.rcode == 0 || a.rcode == 3) return Math.max(1, (System.nanoTime() - t0) / 1_000_000);
                return -1;
            }
        } catch (Exception ignored) { }
        return -1;
    }

    /** چند resolver هم‌زمان: [{"r":"1.2.3.4","ms":42}, ...] فقط سالم‌ها، سریع‌ترین اول */
    static String scan(List<String> list, int timeoutMs, int threads) {
        java.util.concurrent.ExecutorService ex = java.util.concurrent.Executors.newFixedThreadPool(Math.max(1, Math.min(threads, 200)));
        List<java.util.concurrent.Future<long[]>> fs = new ArrayList<>();
        for (String r : list) fs.add(ex.submit(() -> new long[]{probe(r, timeoutMs)}));
        org.json.JSONArray out = new org.json.JSONArray();
        List<Object[]> ok = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            try { long ms = fs.get(i).get(timeoutMs + 3000L, java.util.concurrent.TimeUnit.MILLISECONDS)[0]; if (ms > 0) ok.add(new Object[]{list.get(i), ms}); } catch (Exception ignored) { }
        }
        ex.shutdownNow();
        ok.sort((x, y) -> Long.compare((Long) x[1], (Long) y[1]));
        try { for (Object[] o : ok) out.put(new org.json.JSONObject().put("r", o[0]).put("ms", o[1])); } catch (Exception ignored) { }
        return out.toString();
    }

    /** DNSهای فعلی گوشی (همان که اپراتور داده) + resolverهای پشتیبان */
    static List<String> resolvers(android.content.Context ctx, List<String> extra) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) ctx.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
            android.net.LinkProperties lp = cm.getLinkProperties(cm.getActiveNetwork());
            if (lp != null) for (InetAddress a : lp.getDnsServers()) if (a.getAddress().length == 4) s.add(a.getHostAddress());
        } catch (Throwable ignored) { }
        if (extra != null) s.addAll(extra);
        s.add("1.1.1.1"); s.add("8.8.8.8");
        return new ArrayList<>(s);
    }
}
