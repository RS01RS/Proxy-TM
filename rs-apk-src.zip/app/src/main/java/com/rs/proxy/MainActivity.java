package com.rs.proxy;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** R.S Proxy — صفحهٔ R.S داخل اپ، به‌اضافهٔ تست handshake واقعی و خواندن منابع بدون محدودیت مرورگر. */
public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(48);
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF06122B);
        getWindow().setNavigationBarColor(0xFF06122B);

        web = new WebView(this);
        web.setBackgroundColor(0xFF06122B);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                openExternal(u.toString());   // tg:// و لینک‌های بیرونی → تلگرام / مرورگر
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "RSNative");

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        web.destroy();
        super.onDestroy();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast(url.startsWith("tg:") ? "تلگرام نصب نیست" : "برنامه‌ای برای باز کردن این لینک نیست");
        }
    }

    private void toast(String msg) {
        main.post(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private void callback(String id, String jsonLiteral) {
        final String js = "window.RSNativeCb && window.RSNativeCb(" + JSONObject.quote(id) + "," + jsonLiteral + ")";
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    static String httpGet(String url, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(Math.min(timeoutMs, 15000));
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) R.S-Proxy/1.0");
            if (c.getResponseCode() / 100 != 2) return null;
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total > 4_000_000) break;
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** متدهایی که صفحهٔ R.S از طریق window.RSNative صدا می‌زند. */
    final class Bridge {

        @JavascriptInterface
        public void check(String id, String host, int port, String secret, int timeoutMs) {
            pool.execute(() -> callback(id, ProxyTester.check(host, port, secret, Math.max(timeoutMs, 1500)).toJson()));
        }

        @JavascriptInterface
        public void fetch(String id, String url, int timeoutMs) {
            pool.execute(() -> {
                String t = httpGet(url, Math.max(timeoutMs, 3000));
                callback(id, t == null ? "null" : JSONObject.quote(t));
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            main.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("R.S Proxy", text));
            });
        }

        @JavascriptInterface
        public void open(String url) { main.post(() -> openExternal(url)); }

        @JavascriptInterface
        public void save(String name, String text) {
            pool.execute(() -> {
                try {
                    byte[] data = text.getBytes(StandardCharsets.UTF_8);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentResolver r = getContentResolver();
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, name.endsWith(".csv") ? "text/csv" : name.endsWith(".html") ? "text/html" : "text/plain");
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (uri == null) throw new Exception("no uri");
                        try (OutputStream o = r.openOutputStream(uri)) { o.write(data); }
                        toast("ذخیره شد: Download/" + name);
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        File f = new File(dir, name);
                        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
                        toast("ذخیره شد: " + f.getAbsolutePath());
                    }
                } catch (Exception e) {
                    toast("ذخیره نشد");
                }
            });
        }
    }
}
