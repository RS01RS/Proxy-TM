package com.rs.proxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * تونل DNS را وقتی برنامه در پس‌زمینه است زنده نگه می‌دارد (تلگرام از راه پروکسی SOCKS محلی به آن وصل است).
 * فقط یک اعلان دائمی؛ خود تونل پردازهٔ RsTun است.
 */
public class TunService extends Service {
    static final String CH = "rs_tun";
    static final String STOP = "com.rs.proxy.TUN_STOP";

    static void start(Context c) {
        Intent i = new Intent(c, TunService.class);
        try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i); } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, TunService.class)); } catch (Exception ignored) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            RsTun.stop();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, MainActivity.EN ? "DNS tunnel" : "تونل DNS", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent open = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        PendingIntent stop = PendingIntent.getService(this, 2, new Intent(this, TunService.class).setAction(STOP), fl);
        String title = (MainActivity.EN ? "DNS tunnel on · " : "تونل DNS روشن · ") + RsTun.name;
        String text = (MainActivity.EN ? "Telegram proxy: 127.0.0.1:" : "پروکسی تلگرام: 127.0.0.1:") + RsTun.port;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle(title).setContentText(text)
         .setOngoing(true).setContentIntent(open)
         .addAction(new Notification.Action.Builder(null, MainActivity.EN ? "Stop" : "قطع", stop).build());
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(7, n);
        } catch (Exception e) { stopSelf(); }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() { super.onDestroy(); }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
