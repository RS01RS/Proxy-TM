package com.rs.proxy;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * تأیید از خود تلگرام: درخواست MTProto «req_pq_multi» از داخل پروکسی به سرور تلگرام فرستاده می‌شود.
 * فقط وقتی سرور تلگرام جواب «resPQ» با همان nonce بدهد، پروکسی واقعاً به تلگرام می‌رسد.
 */
final class TgProbe {

    private static final SecureRandom RNG = new SecureRandom();
    static final int DC = 2;

    /** کانال خواندن/نوشتن (TCP خام یا رکوردهای FakeTLS). */
    interface Wire {
        void write(byte[] b) throws IOException;
        byte[] read(int n) throws IOException;
    }

    static final class RawWire implements Wire {
        final OutputStream out; final DataInputStream in;
        RawWire(OutputStream out, DataInputStream in) { this.out = out; this.in = in; }
        public void write(byte[] b) throws IOException { out.write(b); out.flush(); }
        public byte[] read(int n) throws IOException { byte[] b = new byte[n]; in.readFully(b); return b; }
    }

    /** داده داخل رکوردهای TLS application-data (مثل کلاینت تلگرام بعد از handshake FakeTLS). */
    static final class TlsWire implements Wire {
        final OutputStream out; final DataInputStream in;
        final ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] pending = new byte[0];
        boolean first = true;
        TlsWire(OutputStream out, DataInputStream in) { this.out = out; this.in = in; }
        public void write(byte[] b) throws IOException {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            if (first) { o.write(new byte[]{0x14, 3, 3, 0, 1, 1}); first = false; }   // ChangeCipherSpec
            for (int off = 0; off < b.length; off += 16384) {
                int n = Math.min(16384, b.length - off);
                o.write(new byte[]{0x17, 3, 3, (byte) (n >> 8), (byte) n});
                o.write(b, off, n);
            }
            out.write(o.toByteArray()); out.flush();
        }
        public byte[] read(int n) throws IOException {
            while (pending.length < n) {
                byte[] h = new byte[5]; in.readFully(h);
                int len = ((h[3] & 0xff) << 8) | (h[4] & 0xff);
                byte[] p = new byte[len]; in.readFully(p);
                if (h[0] == 0x15) throw new IOException("TLS alert");
                if (h[0] != 0x17) continue;
                pending = ProxyTester.cat(pending, p);
            }
            byte[] r = Arrays.copyOf(pending, n);
            pending = Arrays.copyOfRange(pending, n, pending.length);
            return r;
        }
    }

    static int le32(byte[] b, int off) {
        return ByteBuffer.wrap(b, off, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    /** req_pq_multi بدون رمز (auth_key_id = 0). */
    static byte[] reqPq(byte[] nonce) {
        ByteBuffer b = ByteBuffer.allocate(40).order(ByteOrder.LITTLE_ENDIAN);
        long msgId = ((long) (System.currentTimeMillis() / 1000.0 * 4294967296.0)) & ~3L;
        b.putLong(0).putLong(msgId).putInt(20).putInt(0xbe7e8ef1).put(nonce);
        return b.array();
    }

    /** جواب را بررسی می‌کند: resPQ با همان nonce؟ null یعنی تأیید، وگرنه دلیل رد. */
    static String checkResPq(byte[] msg, byte[] nonce) {
        if (msg.length < 40) return "telegram error";
        if (le32(msg, 20) != 0x05162463) return "not a Telegram reply";
        if (!Arrays.equals(Arrays.copyOfRange(msg, 24, 40), nonce)) return "wrong nonce";
        return null;
    }

    static byte[] sha256(byte[]... parts) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        for (byte[] p : parts) d.update(p);
        return d.digest();
    }

    static Cipher ctr(byte[] key, byte[] iv) throws Exception {
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c;
    }

    private static boolean badStart(byte[] r) {
        if ((r[0] & 0xff) == 0xef) return true;
        int w = le32(r, 0);
        if (w == 0x44414548 || w == 0x54534f50 || w == 0x20544547 || w == 0x4954504f
            || w == 0xdddddddd || w == 0xeeeeeeee || w == 0x02010316) return true;
        return r[4] == 0 && r[5] == 0 && r[6] == 0 && r[7] == 0;
    }

    /**
     * از داخل پروکسی MTProto (کلاسیک/dd/FakeTLS) به تلگرام: لایهٔ obfuscated2 با secret،
     * بستهٔ padded-intermediate و بعد req_pq_multi. null یعنی تلگرام جواب داد.
     */
    static String viaMtproxy(Wire w, byte[] key16) {
        try {
            byte[] r = new byte[64];
            do RNG.nextBytes(r); while (badStart(r));
            r[56] = r[57] = r[58] = r[59] = (byte) 0xdd;
            r[60] = (byte) DC; r[61] = 0;
            byte[] rev = new byte[48];
            for (int i = 0; i < 48; i++) rev[i] = r[55 - i];
            Cipher enc = ctr(sha256(Arrays.copyOfRange(r, 8, 40), key16), Arrays.copyOfRange(r, 40, 56));
            Cipher dec = ctr(sha256(Arrays.copyOfRange(rev, 0, 32), key16), Arrays.copyOfRange(rev, 32, 48));
            byte[] e = enc.update(r);
            System.arraycopy(e, 56, r, 56, 8);

            byte[] nonce = new byte[16]; RNG.nextBytes(nonce);
            byte[] msg = reqPq(nonce);
            int pad = RNG.nextInt(16);
            byte[] padding = new byte[pad]; RNG.nextBytes(padding);
            ByteBuffer pkt = ByteBuffer.allocate(4 + msg.length + pad).order(ByteOrder.LITTLE_ENDIAN);
            pkt.putInt(msg.length + pad).put(msg).put(padding);
            w.write(ProxyTester.cat(r, enc.update(pkt.array())));

            int len = le32(dec.update(w.read(4)), 0) & 0x7fffffff;
            if (len < 4 || len > 1 << 20) return "bad Telegram packet";
            return checkResPq(dec.update(w.read(len)), nonce);
        } catch (java.net.SocketTimeoutException e) {
            return "Telegram did not reply";
        } catch (IOException e) {
            return "closed before Telegram reply";
        } catch (Exception e) {
            return "error " + e.getClass().getSimpleName();
        }
    }

    /** اتصال مستقیم به سرور تلگرام (بعد از CONNECT در SOCKS): intermediate بدون رمز. */
    static String direct(Wire w) {
        try {
            byte[] nonce = new byte[16]; RNG.nextBytes(nonce);
            byte[] msg = reqPq(nonce);
            ByteBuffer pkt = ByteBuffer.allocate(8 + msg.length).order(ByteOrder.LITTLE_ENDIAN);
            pkt.putInt(0xeeeeeeee).putInt(msg.length).put(msg);
            w.write(pkt.array());
            int len = le32(w.read(4), 0) & 0x7fffffff;
            if (len < 4 || len > 1 << 20) return "bad Telegram packet";
            return checkResPq(w.read(len), nonce);
        } catch (java.net.SocketTimeoutException e) {
            return "Telegram did not reply";
        } catch (IOException e) {
            return "closed before Telegram reply";
        } catch (Exception e) {
            return "error " + e.getClass().getSimpleName();
        }
    }
}
