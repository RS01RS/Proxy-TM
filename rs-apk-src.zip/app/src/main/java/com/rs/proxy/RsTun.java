package com.rs.proxy;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;

/**
 * تونل DNS برای نت ملی: موتورهای MasterDNS / StormDNS / CottenDNS (MIT) و Soar (Apache-2.0)
 * هر موتور یک پردازهٔ جدا (lib*.so) است که یک پروکسی SOCKS5 محلی باز می‌کند.
 * کانفیگ هر موتور از پروفایل کاربر (لینک soar:// ، masterdns:// ، … ) ساخته می‌شود؛ هیچ کانفیگی داخل برنامه نیست.
 */
final class RsTun {
    private RsTun() { }

    static final String[][] ENGINES = {     // engine, فایل اجرایی
        {"masterdns", "libmdns.so"}, {"stormdns", "libstorm.so"}, {"cottendns", "libcotten.so"}, {"soar", "libsoar.so"},
    };

    static volatile Process proc;
    static volatile int port = 0;
    static volatile String engine = "", name = "", pid = "";
    static volatile long since = 0;
    private static final StringBuilder log = new StringBuilder();
    private static File conf, res;

    static String bin(String engine) {
        for (String[] e : ENGINES) if (e[0].equals(engine)) return e[1];
        return null;
    }

    /** کدام موتورها داخل این نسخه از برنامه هستند */
    static JSONObject available(Context c) {
        JSONObject o = new JSONObject();
        try {
            for (String[] e : ENGINES) o.put(e[0], new File(c.getApplicationInfo().nativeLibraryDir, e[1]).exists());
        } catch (Exception ignored) { }
        return o;
    }

    private static void hlog(String s) {
        synchronized (log) { log.append(s); if (log.length() > 16000) log.delete(0, log.length() - 12000); }
    }
    static String logs() { synchronized (log) { return log.toString(); } }

    /** رشتهٔ TOML (JSONObject.quote «/» را به «\/» تبدیل می‌کند که در TOML خطاست) */
    static String q(String s) {
        if (s == null) s = "";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\\' || ch == '"') b.append('\\').append(ch);
            else if (ch == '\n') b.append("\\n");
            else if (ch == '\t') b.append("\\t");
            else if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch));
            else b.append(ch);
        }
        return b.append('"').toString();
    }

    /** کانفیگ TOML برای MasterDNS / StormDNS / CottenDNS */
    static String toml(JSONObject srv, int listen) { return toml(srv, listen, null, null, null); }

    /** mode = "cottenmax" فقط برای CottenDNS: کشف resolver مثل Soar (اول وارسی، بعد استفاده) */
    static String toml(JSONObject srv, int listen, String mode, JSONArray cands, File cache) {
        StringBuilder t = new StringBuilder();
        if ("cottenmax".equals(mode)) {
            t.append("TUNNEL_MODE = \"cottenmax\"\nRESOLVER_DISCOVERY_ENABLED = true\nRESOLVER_DISCOVERY_COUNTRY = \"IR\"\n");
            t.append("RESOLVER_DISCOVERY_CANDIDATES = [");
            if (cands != null) for (int i = 0; i < cands.length(); i++) { if (i > 0) t.append(", "); t.append(q(cands.optString(i))); }
            t.append("]\n");
            if (cache != null) t.append("RESOLVER_DISCOVERY_CACHE_FILE = ").append(q(cache.getAbsolutePath())).append('\n');
        }
        JSONArray doms = srv.optJSONArray("domains");
        t.append("DOMAINS = [");
        if (doms != null && doms.length() > 0) for (int i = 0; i < doms.length(); i++) { if (i > 0) t.append(", "); t.append(q(doms.optString(i))); }
        else t.append(q(srv.optString("domain")));
        t.append("]\n");
        t.append("DATA_ENCRYPTION_METHOD = ").append(srv.optInt("encryption_method", 1)).append('\n');
        t.append("ENCRYPTION_KEY = ").append(q(srv.optString("encryption_key"))).append('\n');
        t.append("PROTOCOL_TYPE = \"SOCKS5\"\nLISTEN_IP = \"127.0.0.1\"\nLISTEN_PORT = ").append(listen).append('\n');
        t.append("SOCKS5_AUTH = false\nLOCAL_DNS_ENABLED = false\nSAVE_MTU_SERVERS_TO_FILE = false\nLOCAL_DNS_CACHE_PERSIST_TO_FILE = false\n");
        return t.toString();
    }

    /** کانفیگ JSON برای soarsocks */
    static String soarJson(JSONObject p, JSONArray resolvers, int listen, File dir) throws Exception {
        JSONObject srv = p.optJSONObject("server");
        JSONObject o = new JSONObject();
        o.put("domain", srv.optString("domain"));
        o.put("public_key", srv.optString("public_key"));
        // فقط resolverهای خود پروفایل «مورد اعتماد»اند؛ بقیه (بانک برنامه + DNS گوشی) اول وارسی می‌شوند
        JSONArray own = new JSONArray(), cand = new JSONArray();
        LinkedHashSet<String> mine = new LinkedHashSet<>();
        JSONArray pr = p.optJSONArray("resolvers");
        if (pr != null) for (int i = 0; i < pr.length(); i++) { String x = pr.optString(i).trim(); if (!x.isEmpty()) mine.add(x); }
        for (int i = 0; i < resolvers.length(); i++) { String x = resolvers.optString(i); if (mine.contains(x)) own.put(x); else cand.put(x); }
        o.put("resolvers", own);
        o.put("candidates", cand);
        o.put("cache", new File(dir, "soar_ok_" + Integer.toHexString(srv.optString("domain").hashCode()) + ".txt").getAbsolutePath());
        o.put("listen", "127.0.0.1:" + listen);
        JSONObject s = p.optJSONObject("soarSettings");
        o.put("soarSettings", s == null ? new JSONObject().put("country", "IR") : s);
        return o.toString();
    }

    /**
     * یک پروفایل را بالا می‌آورد و تست می‌کند (پاسخ از داخل تونل).
     * خروجی: {"ok":true,"port":…,"ms":…} یا {"ok":false,"err":"…"}
     */
    static synchronized String start(Context c, String profileJson, String extraResolversJson, int timeoutMs) {
        JSONObject out = new JSONObject();
        try {
            stop();
            JSONObject p = new JSONObject(profileJson);
            if (p.has("profile")) p = p.getJSONObject("profile");
            String eng = p.optString("engine", "soar").toLowerCase(java.util.Locale.US);
            String b = bin(eng);
            if (b == null) throw new Exception("unknown engine: " + eng);
            File f = new File(c.getApplicationInfo().nativeLibraryDir, b);
            if (!f.exists()) throw new Exception(english() ? "this engine isn't in this build of the app" : "این موتور در این نسخهٔ برنامه نیست");
            JSONObject srv = p.optJSONObject("server");
            if (srv == null || srv.optString("domain").isEmpty()) throw new Exception(english() ? "profile has no domain" : "پروفایل دامنه ندارد");
            // resolverها: پروفایل + بانک برنامه + DNS گوشی
            LinkedHashSet<String> rs = new LinkedHashSet<>();
            JSONArray pr = p.optJSONArray("resolvers");
            if (pr != null) for (int i = 0; i < pr.length(); i++) rs.add(pr.optString(i).trim());
            try { JSONArray ex = new JSONArray(extraResolversJson); for (int i = 0; i < ex.length(); i++) rs.add(ex.optString(i).trim()); } catch (Exception ignored) { }
            rs.addAll(RsDns.resolvers(c, null));
            rs.remove("");
            // موتورها قبل از باز کردن پورت روی هر resolver تست MTU می‌کنند؛ تعداد زیاد = هیچ‌وقت بالا نمی‌آید
            if (rs.size() > 60) { LinkedHashSet<String> cut = new LinkedHashSet<>(); for (String x : rs) { if (cut.size() >= 60) break; cut.add(x); } rs = cut; }
            JSONArray rsa = new JSONArray(); for (String r : rs) rsa.put(r);
            File dir = new File(c.getFilesDir(), "tun"); dir.mkdirs();
            synchronized (log) { log.setLength(0); }
            // CottenDNS: اول حالت معمولی (legacy)؛ اگر تست MTU هیچ resolverی را قبول نکرد، حالت CottenMax با وارسی resolverها
            String want = p.optString("tunnel_mode", srv.optString("tunnel_mode", "")).toLowerCase(java.util.Locale.US);
            // پروفایل‌های WhiteDNS ممکن است حالت را در تنظیمات جدا داشته باشند (cottenmax / legacy)
            if (want.isEmpty() && profileJson.toLowerCase(java.util.Locale.US).contains("cottenmax")) want = "cottenmax";
            // اگر پروفایل CottenMax خواسته بود و نشد (مثلاً دامنه برای CottenMax طولانی است)، حالت معمولی هم امتحان می‌شود
            String[] modes = "cottendns".equals(eng) ? (want.equals("cottenmax") ? new String[]{"cottenmax", "legacy"} : new String[]{"legacy", "cottenmax"}) : new String[]{""};
            boolean longDomain = false;
            long until = System.currentTimeMillis() + timeoutMs;
            String lastErr = null; int lp = 0; long t0 = 0;
            boolean ok = false;
            for (int mi = 0; mi < modes.length && !ok; mi++) {
                String mode = modes[mi];
                if (mi > 0) { stopProc(); hlog("--- " + (english() ? "retrying in " + mode + " mode" : "تلاش دوباره در حالت " + ("legacy".equals(mode) ? "معمولی (legacy)" : "CottenMax")) + " ---\n"); }
                // سهم زمان: حالت اول نصف وقت، اگر حالت دیگری مانده
                long myUntil = mi < modes.length - 1 ? System.currentTimeMillis() + (until - System.currentTimeMillis()) / 2 : until;
                lp = freePort();
                conf = new File(dir, "soar".equals(eng) ? "client.json" : "client_config.toml");
                res = new File(dir, "client_resolvers.txt");
                File cache = new File(dir, "ok_" + eng + "_" + Integer.toHexString(srv.optString("domain").hashCode()) + ".txt");
                try (FileOutputStream o = new FileOutputStream(conf)) {
                    o.write(("soar".equals(eng) ? soarJson(p, rsa, lp, dir) : toml(srv, lp, mode, rsa, cache)).getBytes(StandardCharsets.UTF_8));
                }
                StringBuilder rl = new StringBuilder(); for (String x : rs) rl.append(x).append('\n');
                try (FileOutputStream o = new FileOutputStream(res)) { o.write(rl.toString().getBytes(StandardCharsets.UTF_8)); }
                ProcessBuilder pb = "soar".equals(eng)
                    ? new ProcessBuilder(f.getAbsolutePath(), "-c", conf.getAbsolutePath())
                    : new ProcessBuilder(f.getAbsolutePath(), "-config", conf.getAbsolutePath(), "-resolvers", res.getAbsolutePath());
                pb.directory(dir); pb.redirectErrorStream(true);
                pb.environment().put("HOME", dir.getAbsolutePath());
                hlog("--- " + eng + (mode.isEmpty() ? "" : " (" + mode + ")") + " · " + p.optString("name") + " · " + rs.size() + " resolvers ---\n");
                int mark = logs().length();
                final Process pr2 = pb.start();
                proc = pr2; engine = eng; name = p.optString("name"); port = lp;
                Thread rd = new Thread(() -> {
                    try (InputStream in = pr2.getInputStream()) {
                        byte[] buf = new byte[4096]; int n;
                        while ((n = in.read(buf)) > 0) hlog(new String(buf, 0, n, StandardCharsets.UTF_8).replaceAll("\u001B\\[[0-9;]*m", "").replaceAll("<[a-z/]+>", ""));
                    } catch (Exception ignored) { }
                });
                rd.setDaemon(true); rd.start();
                // صبر برای باز شدن پورت SOCKS (موتورهای MasterDNS/Cotten اول MTU را تست می‌کنند)
                boolean open = false, mtuFail = false;
                while (System.currentTimeMillis() < myUntil && pr2.isAlive()) {
                    String lg = logs(); lg = lg.length() > mark ? lg.substring(mark) : "";
                    String lgl = lg.toLowerCase(java.util.Locale.US);
                    // CottenDNS بعد از ردِ همه روی UDP، کل فهرست را روی TCP هم تست می‌کند؛ اگر آن هم رد شد → حالت بعدی
                    if (lgl.contains("mtu tests failed") || (lgl.contains("no valid connections") && (lgl.indexOf("no valid connections") != lgl.lastIndexOf("no valid connections") || !lgl.contains("retrying the whole fleet")))) { mtuFail = true; break; }
                    try (java.net.Socket so = new java.net.Socket()) { so.connect(new InetSocketAddress("127.0.0.1", lp), 300); open = true; break; }
                    catch (Exception e) { Thread.sleep(300); }
                }
                if (!open) {
                    String why;
                    if (!pr2.isAlive() && logs().toLowerCase(java.util.Locale.US).contains("insufficient initial handshake capacity")) longDomain = true;
                    if (mtuFail) why = english() ? "no resolver passed the MTU test with this server" : "هیچ resolverی تست MTU این سرور را رد نکرد";
                    else if (!pr2.isAlive()) why = english() ? "engine stopped (code " + pr2.exitValue() + ")" : "موتور بسته شد (کد " + pr2.exitValue() + ")";
                    else why = english() ? "tunnel didn't start in time (no resolver answered the server)" : "تونل به‌موقع بالا نیامد (هیچ resolverی به سرور جواب نداد)";
                    lastErr = lastLine(why);
                    continue;
                }
                // تست واقعی از داخل تونل؛ تا آخر وقت دوباره امتحان می‌شود (Soar/CottenMax اول resolverها را وارسی می‌کنند)
                t0 = System.currentTimeMillis();
                String[] targets = {"http://www.gstatic.com/generate_204", "http://cp.cloudflare.com/generate_204", "http://connectivitycheck.gstatic.com/generate_204"};
                int k = 0;
                while (!ok && pr2.isAlive()) {
                    long left = myUntil - System.currentTimeMillis();
                    if (left < 2500 && k > 0) break;
                    // Soar/CottenMax: باز شدن اولین اتصال روی شبکهٔ پرافت تا یک دقیقه طول می‌کشد
                    int per = "soar".equals(eng) || "cottenmax".equals(mode) ? 60000 : 20000;
                    ok = probe(lp, (int) Math.max(4000, Math.min(per, left)), targets[k++ % targets.length]);
                    if (!ok) Thread.sleep(800);
                }
                if (!ok) lastErr = lastLine(english() ? "tunnel is up but nothing comes back" : "تونل بالا آمد ولی جوابی از داخلش نیامد");
            }
            if (!ok && longDomain) lastErr = (english()
                ? "the server domain is too long for CottenMax (normal mode didn't connect either). On the server, use a shorter subdomain, e.g. c.example.com · "
                : "دامنهٔ سرور برای CottenMax طولانی است (حالت معمولی هم وصل نشد). روی سرور یک زیردامنهٔ کوتاه‌تر بساز، مثلاً c.دامنه · ") + (lastErr == null ? "" : lastErr);
            if (!ok) throw new Exception(lastErr == null ? "?" : lastErr);
            since = System.currentTimeMillis();
            out.put("ok", true); out.put("res", rs.size()); out.put("port", lp); out.put("ms", System.currentTimeMillis() - t0); out.put("engine", eng);
        } catch (Throwable t) {
            stop();
            try { out.put("ok", false); out.put("err", String.valueOf(t.getMessage())); } catch (Exception ignored) { }
        }
        return out.toString();
    }

    private static String lastLine(String def) {
        String l = logs().trim();
        if (l.isEmpty()) return def;
        String[] ls = l.split("\n");
        for (int i = ls.length - 1; i >= 0; i--) if (ls[i].contains("ERROR") || ls[i].contains("rror")) return def + " · " + clip(ls[i].replaceAll("^\\S+ \\S+ ", "").trim());
        return def + " · " + clip(ls[ls.length - 1].trim());
    }
    private static String clip(String s) { return s.length() > 160 ? s.substring(0, 160) + "…" : s;
    }

    /** یک درخواست HTTP کوچک از داخل SOCKS تونل */
    static boolean probe(int p, int timeoutMs) { return probe(p, timeoutMs, "http://www.gstatic.com/generate_204"); }

    static boolean probe(int p, int timeoutMs, String url) {
        HttpURLConnection h = null;
        try {
            java.net.Proxy px = new java.net.Proxy(java.net.Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", p));
            h = (HttpURLConnection) new URL(url).openConnection(px);
            h.setConnectTimeout(timeoutMs); h.setReadTimeout(timeoutMs); h.setUseCaches(false);
            int code = h.getResponseCode();
            return code == 204 || code == 200;
        } catch (Exception e) { return false; }
        finally { if (h != null) h.disconnect(); }
    }

    private static void stopProc() {
        Process p = proc; proc = null; port = 0;
        if (p != null) { p.destroy(); try { if (!p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS)) p.destroyForcibly(); } catch (Exception ignored) { } }
    }

    static synchronized void stop() {
        Process p = proc; proc = null;
        if (p != null) { p.destroy(); try { if (!p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS)) p.destroyForcibly(); } catch (Exception ignored) { } }
        port = 0; since = 0; engine = ""; name = "";
    }

    static boolean running() { Process p = proc; return p != null && p.isAlive() && port > 0; }

    static String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("on", running()); o.put("port", running() ? port : 0); o.put("engine", engine); o.put("name", name); o.put("since", since);
            return o.toString();
        } catch (Exception e) { return "{\"on\":false}"; }
    }

    private static boolean english() { return MainActivity.EN; }

    /** پورت ثابت (اگر آزاد بود) تا پروکسی ذخیره‌شده در تلگرام بعد از هر بار وصل شدن عوض نشود */
    static volatile int prefPort = 0;

    private static int freePort() {
        if (prefPort > 0) {
            try (java.net.ServerSocket s = new java.net.ServerSocket(prefPort, 1, java.net.InetAddress.getByName("127.0.0.1"))) { return prefPort; }
            catch (Exception ignored) { }
        }
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))) { return s.getLocalPort(); }
        catch (Exception e) { return 24000 + (int) (Math.random() * 20000); }
    }
}
