package com.rs.proxy;

import android.app.Activity;

/**
 * جای تبلیغات. نسخهٔ پیش‌فرض خالی است تا برنامه بدون حساب AdMob هم ساخته شود.
 * برای فعال کردن تبلیغ واقعی: راهنمای ADMOB_SETUP.md را دنبال کن (این فایل را با نسخهٔ AdMob جایگزین می‌کنی).
 */
final class AdHook {
    static final boolean AVAILABLE = false;   // با نسخهٔ AdMob می‌شود true
    private AdHook() { }
    static void banner(Activity a, boolean on) { }
    static void interstitial(Activity a) { }
}
