package com.rs.proxy;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * تست واقعی پروکسی MTProto (بدون وابستگی به اندروید، قابل تست روی کامپیوتر).
 * FakeTLS: handshake کامل با secret؛ اگر سرور با همان secret امضا کند، پروکسی سالم است.
 * همهٔ انواع: فقط وقتی «verified» که خود سرور تلگرام از داخل پروکسی جواب بدهد (TgProbe).
 */
public final class ProxyTester {

    private static final SecureRandom RNG = new SecureRandom();

    public static final class Result {
        public String status;   // verified (Telegram replied) | proxy-ok | site-up | bad-secret | rejected | dead
        public Integer ms;      // زمان اتصال TCP
        public String why;

        Result(String status, Integer ms, String why) { this.status = status; this.ms = ms; this.why = why; }

        public String toJson() {
            return "{\"status\":\"" + status + "\",\"ms\":" + (ms == null ? "null" : ms) +
                   ",\"why\":\"" + (why == null ? "" : why.replace("\\", "\\\\").replace("\"", "'")) + "\"}";
        }
    }

    /** secret را به بایت تبدیل می‌کند (hex یا base64url). */
    static byte[] decodeSecret(String s) {
        s = s.trim();
        if (s.matches("(?i)[0-9a-f]+") && s.length() % 2 == 0) {
            byte[] out = new byte[s.length() / 2];
            for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
            return out;
        }
        String b = s.replace('-', '+').replace('_', '/');
        while (b.length() % 4 != 0) b += "=";
        return Base64.getDecoder().decode(b);
    }

    public static Result check(String host, int port, String secret, int timeoutMs) {
        byte[] raw;
        try { raw = decodeSecret(secret); } catch (Exception e) { return new Result("dead", null, "bad secret format"); }
        if (raw.length < 16) return new Result("dead", null, "short secret");

        // ۱. پینگ TCP (بهترین از دو بار)
        Integer best = null;
        int pingTries = timeoutMs >= 10000 ? 1 : 2;   // با زمان بلند، یک بار کافی است
        for (int i = 0; i < pingTries; i++) {
            long t0 = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), timeoutMs);
                int ms = (int) ((System.nanoTime() - t0) / 1_000_000);
                best = best == null ? ms : Math.min(best, ms);
                break;   // یک اتصال موفق کافی است
            } catch (Exception ignored) { }
        }
        if (best == null) return new Result("dead", null, "no TCP");

        boolean fakeTls = (raw[0] & 0xff) == 0xee && raw.length > 17;
        if (!fakeTls) {
            // کلاسیک و dd: لایهٔ obfuscated2 با secret و درخواست مستقیم از سرور تلگرام
            byte[] k = (raw[0] & 0xff) == 0xdd && raw.length >= 17 ? Arrays.copyOfRange(raw, 1, 17) : Arrays.copyOf(raw, 16);
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), timeoutMs);
                s.setSoTimeout(Math.max(timeoutMs, 6000));
                String err = TgProbe.viaMtproxy(new TgProbe.RawWire(s.getOutputStream(), new DataInputStream(s.getInputStream())), k);
                if (err == null) return new Result("verified", best, "Telegram replied");
                return new Result("rejected", best, err);
            } catch (Exception e) {
                return new Result("rejected", best, "connect failed on 2nd try");
            }
        }

        byte[] key = Arrays.copyOfRange(raw, 1, 17);
        byte[] domain = Arrays.copyOfRange(raw, 17, raw.length);
        try {
            return fakeTlsVerify(host, port, key, domain, timeoutMs, best);
        } catch (Exception e) {
            return new Result("rejected", best, "error " + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- FakeTLS
    static byte[] ext(int type, byte[] data) {
        ByteBuffer b = ByteBuffer.allocate(4 + data.length);
        b.putShort((short) type).putShort((short) data.length).put(data);
        return b.array();
    }

    static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    static byte[] u16(int v) { return new byte[]{(byte) (v >> 8), (byte) v}; }

    static byte[] hex(String h) {
        byte[] out = new byte[h.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16);
        return out;
    }

    static byte[] rnd(int n) { byte[] b = new byte[n]; RNG.nextBytes(b); return b; }

    /** ClientHello شبیه مرورگر با SNI دامنهٔ secret، طول رکورد ۵۱۲ (مثل کلاینت تلگرام). */
    static byte[] clientHello(byte[] domain) {
        byte[] alpn = cat(new byte[]{2}, "h2".getBytes(), new byte[]{8}, "http/1.1".getBytes());
        byte[] sig = hex("04030804040105030805050108060601");
        byte[] exts = cat(
            ext(0x0000, cat(u16(domain.length + 3), new byte[]{0}, u16(domain.length), domain)),
            ext(0x0017, new byte[0]),
            ext(0xFF01, new byte[]{0}),
            ext(0x000A, cat(u16(8), hex("001d001700180019"))),
            ext(0x000B, new byte[]{1, 0}),
            ext(0x0023, new byte[0]),
            ext(0x0010, cat(u16(alpn.length), alpn)),
            ext(0x000D, cat(u16(sig.length), sig)),
            ext(0x0033, cat(u16(36), u16(0x001D), u16(32), rnd(32))),
            ext(0x002D, new byte[]{1, 1}),
            ext(0x002B, new byte[]{4, 3, 4, 3, 3})
        );
        byte[] ciphers = hex("130113021303c02bc02fc02cc030cca9cca8c013c014009c009d002f0035");
        byte[] head = cat(new byte[]{3, 3}, new byte[32], new byte[]{0x20}, rnd(32), u16(ciphers.length), ciphers, new byte[]{1, 0});
        int cur = 4 + head.length + 2 + exts.length;
        int pad = 512 - cur - 4;
        if (pad >= 0) exts = cat(exts, ext(0x0015, new byte[pad]));
        byte[] body = cat(head, u16(exts.length), exts);
        byte[] hs = cat(new byte[]{1, (byte) (body.length >> 16), (byte) (body.length >> 8), (byte) body.length}, body);
        return cat(new byte[]{0x16, 3, 1}, u16(hs.length), hs);
    }

    static byte[] hmac(byte[] key, byte[] msg) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(key, "HmacSHA256"));
        return m.doFinal(msg);
    }

    static Result fakeTlsVerify(String host, int port, byte[] key, byte[] domain, int timeoutMs, int ping) throws Exception {
        try (Socket s = new Socket()) {
            try {
                s.connect(new InetSocketAddress(host, port), timeoutMs);
            } catch (IOException e) {
                return new Result("rejected", ping, "connect failed on 2nd try");
            }
            s.setSoTimeout(Math.max(timeoutMs, 6000));   // handshake کامل چند رفت‌وبرگشت لازم دارد
            byte[] hello = clientHello(domain);
            byte[] digest = hmac(key, hello);
            byte[] ts = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt((int) (System.currentTimeMillis() / 1000)).array();
            byte[] clientRand = Arrays.copyOf(digest, 32);
            for (int i = 0; i < 4; i++) clientRand[28 + i] = (byte) (digest[28 + i] ^ ts[i]);
            System.arraycopy(clientRand, 0, hello, 11, 32);

            OutputStream out = s.getOutputStream();
            out.write(hello);
            out.flush();

            DataInputStream in = new DataInputStream(s.getInputStream());
            byte[] first = new byte[5];
            try {
                int n = readSome(in, first);
                if (n <= 0) return new Result("rejected", ping, "closed after hello");
                if (n < 5) in.readFully(first, n, 5 - n);
            } catch (SocketTimeoutException e) {
                return new Result("rejected", ping, "no reply after hello");
            } catch (IOException e) {
                return new Result("rejected", ping, "reset after hello");
            }
            if (first[0] != 0x16) return new Result("rejected", ping, "non-TLS reply");

            ByteArrayOutputStream resp = new ByteArrayOutputStream();
            try {
                byte[] hdr = first;
                for (int rec = 0; rec < 3; rec++) {
                    if (rec > 0) { hdr = new byte[5]; in.readFully(hdr); }
                    int len = ((hdr[3] & 0xff) << 8) | (hdr[4] & 0xff);
                    byte[] payload = new byte[len];
                    in.readFully(payload);
                    resp.write(hdr); resp.write(payload);
                    if (hdr[0] == 0x17) break;
                }
            } catch (SocketTimeoutException | EOFException e) {
                return new Result("rejected", ping, "partial TLS reply");
            }
            byte[] data = resp.toByteArray();
            if (data.length < 43) return new Result("rejected", ping, "short TLS reply");
            byte[] got = Arrays.copyOfRange(data, 11, 43);
            byte[] zeroed = data.clone();
            Arrays.fill(zeroed, 11, 43, (byte) 0);
            byte[] expect = hmac(key, cat(clientRand, zeroed));
            if (!MessageDigest.isEqual(expect, got)) return new Result("bad-secret", ping, "digest mismatch");
            // secret درست است؛ حالا از داخل همین اتصال از خود تلگرام جواب بگیر
            String err = TgProbe.viaMtproxy(new TgProbe.TlsWire(out, in), key);
            if (err == null) return new Result("verified", ping, "Telegram replied");
            return new Result("proxy-ok", ping, "secret ok, " + err);
        }
    }

    static int readSome(InputStream in, byte[] buf) throws IOException {
        int n = in.read(buf, 0, buf.length);
        return n;
    }

    // ---------------------------------------------------------------- SOCKS5
    /** سرورهای تلگرام برای تست: اگر پروکسی بتواند به یکی وصل شود، واقعاً کار می‌کند. */
    static final String[] TG_DC = {"149.154.167.51", "149.154.175.53", "91.108.56.130"};

    /**
     * تست واقعی SOCKS5: سلام SOCKS، احراز هویت (در صورت نیاز) و درخواست CONNECT به سرور تلگرام.
     * verified = پروکسی به تلگرام وصل شد | rejected = SOCKS جواب داد ولی وصل نکرد | dead = جواب نداد
     */
    public static Result checkSocks(String host, int port, String user, String pass, int timeoutMs) {
        long t0 = System.nanoTime();
        try (Socket s = new Socket()) {
            try {
                s.connect(new InetSocketAddress(host, port), timeoutMs);
            } catch (IOException e) {
                return new Result("dead", null, "no TCP");
            }
            int ping = (int) ((System.nanoTime() - t0) / 1_000_000);
            s.setSoTimeout(Math.max(timeoutMs, 6000));
            OutputStream out = s.getOutputStream();
            DataInputStream in = new DataInputStream(s.getInputStream());
            boolean auth = user != null && !user.isEmpty();
            out.write(auth ? new byte[]{5, 2, 0, 2} : new byte[]{5, 1, 0});
            out.flush();
            byte[] g = new byte[2];
            try { in.readFully(g); } catch (IOException e) { return new Result("rejected", ping, "not a SOCKS5 server"); }
            if (g[0] != 5) return new Result("rejected", ping, "not a SOCKS5 server");
            if ((g[1] & 0xff) == 2) {
                if (!auth) return new Result("rejected", ping, "needs password");
                byte[] u = user.getBytes(), pw = (pass == null ? "" : pass).getBytes();
                out.write(cat(new byte[]{1, (byte) u.length}, u, new byte[]{(byte) pw.length}, pw));
                out.flush();
                byte[] ar = new byte[2];
                in.readFully(ar);
                if (ar[1] != 0) return new Result("rejected", ping, "wrong password");
            } else if ((g[1] & 0xff) != 0) {
                return new Result("rejected", ping, "no acceptable auth");
            }
            String[] ip = TG_DC[0].split("\\.");
            byte[] req = {5, 1, 0, 1, (byte) Integer.parseInt(ip[0]), (byte) Integer.parseInt(ip[1]),
                          (byte) Integer.parseInt(ip[2]), (byte) Integer.parseInt(ip[3]), 0x01, (byte) 0xBB};
            out.write(req);
            out.flush();
            byte[] rep = new byte[4];
            try { in.readFully(rep); }
            catch (SocketTimeoutException e) { return new Result("rejected", ping, "no reply to CONNECT"); }
            catch (IOException e) { return new Result("rejected", ping, "closed on CONNECT"); }
            if (rep[0] != 5 || rep[1] != 0) return new Result("rejected", ping, "CONNECT refused (" + (rep[1] & 0xff) + ")");
            // بقیهٔ جواب CONNECT (آدرس bind) را بخوان
            try {
                int at = rep[3] & 0xff;
                int skip = at == 1 ? 6 : at == 4 ? 18 : at == 3 ? (in.readUnsignedByte() + 2) : -1;
                if (skip < 0) return new Result("rejected", ping, "bad CONNECT reply");
                in.readFully(new byte[skip]);
            } catch (IOException e) {
                return new Result("rejected", ping, "closed on CONNECT");
            }
            // «موفق» گفتن SOCKS کافی نیست: باید خود سرور تلگرام جواب بدهد
            String err = TgProbe.direct(new TgProbe.RawWire(out, in));
            if (err == null) return new Result("verified", ping, "Telegram replied");
            return new Result("proxy-ok", ping, "CONNECT ok, " + err);
        } catch (Exception e) {
            return new Result("rejected", null, "error " + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- WEB proxy
    /**
     * WEB proxy تلگرام: سرور یک سایت HTTPS معمولی است. از بیرون فقط می‌شود دید سایت با گواهی معتبر
     * بالا است؛ درستی secret را فقط خود تلگرام می‌سنجد.
     */
    public static Result checkWeb(String host, int timeoutMs) {
        javax.net.ssl.HttpsURLConnection c = null;
        long t0 = System.nanoTime();
        try {
            c = (javax.net.ssl.HttpsURLConnection) new java.net.URL("https://" + host + "/").openConnection();
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
            int code = c.getResponseCode();
            int ms = (int) ((System.nanoTime() - t0) / 1_000_000);
            if (code >= 200 && code < 500) return new Result("site-up", ms, "site up (HTTP " + code + "), secret checked only by Telegram");
            return new Result("rejected", ms, "HTTP " + code);
        } catch (javax.net.ssl.SSLException e) {
            return new Result("rejected", null, "bad TLS / blocked");
        } catch (java.net.UnknownHostException e) {
            return new Result("dead", null, "DNS failed");
        } catch (Exception e) {
            return new Result("dead", null, e.getClass().getSimpleName());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** برای تست روی کامپیوتر: java ProxyTester host port secret */
    public static void main(String[] a) {
        System.out.println(check(a[0], Integer.parseInt(a[1]), a[2], 3000).toJson());
    }
}
