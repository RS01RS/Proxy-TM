# ===== TM Proxy — قوانین مبهم‌سازی (R8) =====
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.rs.proxy.MainActivity { *; }
-keep class com.rs.proxy.RsFiles { *; }
-keep class com.rs.proxy.TunService { *; }
-keep class com.rs.proxy.BuildConfig { *; }
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
-keepclassmembers enum * { public static **[] values(); public static ** valueOf(java.lang.String); }
-dontwarn org.conscrypt.**
-dontwarn javax.annotation.**
