module vpnscan/soarsocks

go 1.25.0

require github.com/getlantern/soar v0.2.3
